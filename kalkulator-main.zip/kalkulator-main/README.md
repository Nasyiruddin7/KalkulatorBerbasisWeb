# kalkulator

[ID] Sebuah aplikasi kalkulator sederhana yang memanfaatkan Web Storage API untuk menyimpan data hasil kalkulasi.
~
[EN] A simple calculator application that utilizes the Web Storage API to store calculated data.
https://mrizqighana.github.io/kalkulator
